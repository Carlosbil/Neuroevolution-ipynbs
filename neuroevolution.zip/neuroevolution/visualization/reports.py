"""
Reporting utilities for notebook orchestration.

Extracts verbose reporting logic from notebooks while preserving output format.
"""

from __future__ import annotations

import json
import os
from datetime import datetime
from typing import Optional

import torch

from ..models.architecture_formatting import format_genome_architecture
from ..models.evolvable_cnn import EvolvableCNN
from ..models.genome_validator import calculate_inception_branch_channels


def _format_architecture(genome: dict) -> str:
    return format_genome_architecture(genome)


def _display_reference_architecture(best_genome, config, neuroevolution, execution_time):
    """Report the native graph rather than empty editable-gene placeholders."""
    with torch.device('meta'):
        model = EvolvableCNN(best_genome, config)
    parameter_count = sum(parameter.numel() for parameter in model.parameters())
    print(model.get_architecture_summary())
    print(f"Genome: {best_genome['id']} | fitness: {best_genome['fitness']:.2f}%")
    print(f"Optimizer: {best_genome['optimizer']} | learning rate: {best_genome['learning_rate']}")
    print(f"Parameters: {parameter_count:,}")
    print(model.model)
    output_path = os.path.join(config['artifacts_dir'], 'best_reference_architecture.json')
    os.makedirs(config['artifacts_dir'], exist_ok=True)
    with open(output_path, 'w', encoding='utf-8') as stream:
        json.dump({'best_genome': best_genome, 'config_used': config,
                   'parameter_count': parameter_count, 'native_graph': str(model.model),
                   'input_adapter': list(model.input_size),
                   'final_generation': neuroevolution.generation,
                   'execution_time': str(execution_time)}, stream, indent=2, default=str)
    print(f"Results saved to: {output_path}")


def display_best_architecture(
    best_genome: dict,
    config: dict,
    neuroevolution,
    execution_time: Optional[object] = None
) -> None:
    """
    Display detailed best-architecture report and save JSON snapshot.

    Args:
        best_genome: Best genome dictionary.
        config: Configuration dictionary.
        neuroevolution: HybridNeuroevolution instance.
        execution_time: Optional execution time metadata.
    """
    if best_genome.get('model_kind') == 'reference':
        _display_reference_architecture(best_genome, config, neuroevolution, execution_time)
        return
    is_spectrogram = str(config.get('input_modality', 'audio')).lower() in {'spectrogram', 'image'}
    dimension = '2D' if is_spectrogram else '1D'
    data_name = 'spectrogram' if is_spectrogram else 'audio'
    input_description = (
        f"Spectrogram ({config['num_frequency_bins']} frequency bins x {config['sequence_length']} frames)"
        if is_spectrogram else f"1D Audio Signal (length={config['sequence_length']})"
    )
    print("=" * 60)
    print(f"    BEST EVOLVED ARCHITECTURE ({dimension} {data_name.upper()})")
    print("=" * 60)

    print("\nGENERAL INFORMATION:")
    print(f"   Genome ID: {best_genome['id']}")
    print(f"   Fitness Achieved: {best_genome['fitness']:.2f}%")
    print(f"   Generation: {neuroevolution.generation}")
    print(f"   Dataset: {config['dataset']}")
    print(f"   Dataset ID: {config.get('dataset_id', 'N/A')}")
    print(f"   Fold: {config.get('current_fold', 'N/A')}")
    if best_genome.get("architecture_template_id"):
        print(f"   Template: {best_genome.get('architecture_template_id')}")
        print(f"   Template Family: {best_genome.get('architecture_template_family', 'N/A')}")
        print(f"   Template Origin: {best_genome.get('architecture_template_origin', 'N/A')}")

    print("\nNETWORK ARCHITECTURE:")
    print(f"   Input: {input_description}")
    print(f"   Convolutional Layers (Conv{dimension}): {best_genome['num_conv_layers']}")
    print(f"   Fully Connected Layers: {best_genome['num_fc_layers']}")
    print(f"   Residual Enabled: {best_genome.get('residual_enabled', False)}")
    if best_genome.get("residual_enabled", False):
        print(f"   Residual Block Size: {best_genome.get('residual_block_size', 2)}")
        print(f"   Residual Projection: {best_genome.get('residual_projection', 'auto')}")
    print(f"   Inception Enabled: {best_genome.get('inception_enabled', False)}")
    if best_genome.get("inception_enabled", False):
        print(f"   Inception Reduction Ratio: {best_genome.get('inception_reduction_ratio', 0.5)}")
        print(f"   Inception Pool Branch: {best_genome.get('inception_pool_branch', True)}")
    print(f"   Output: {config['num_classes']} classes")

    print(f"\nCONVOLUTIONAL LAYER DETAILS ({dimension}):")
    residual_enabled = best_genome.get("residual_enabled", False)
    residual_block_size = best_genome.get("residual_block_size", 2)
    inception_enabled = best_genome.get("inception_enabled", False)
    inception_pool_branch = best_genome.get("inception_pool_branch", True)
    min_branch_channels = int(config.get("inception_min_branch_channels", 1))
    for i in range(best_genome["num_conv_layers"]):
        filters = best_genome["filters"][i]
        kernel = best_genome["kernel_sizes"][i]
        activation = best_genome["activations"][i % len(best_genome["activations"])]
        print(f"   Conv{dimension}-{i+1}: {filters} filters, kernel_size={kernel}, activation={activation}")
        if inception_enabled:
            branch_channels = calculate_inception_branch_channels(
                filters,
                pool_branch=inception_pool_branch,
                min_branch_channels=min_branch_channels,
            )
            print(
                f"             -> Inception branches {branch_channels}; "
                f"medium kernel=3, wide kernel={kernel}, MaxPool{dimension}(2) after module"
            )
        elif residual_enabled:
            block_number = (i // residual_block_size) + 1
            block_position = (i % residual_block_size) + 1
            print(
                f"             -> Residual block {block_number}, unit {block_position}; "
                f"MaxPool{dimension}(2) after block"
            )
        else:
            print(f"             -> BatchNorm{dimension} -> {activation.upper()} -> MaxPool{dimension}(2)")

    print("\nFULLY CONNECTED LAYER DETAILS:")
    for i, nodes in enumerate(best_genome["fc_nodes"]):
        print(f"   FC{i+1}: {nodes} neurons -> BatchNorm1D -> ReLU -> Dropout({best_genome['dropout_rate']:.3f})")
    print(f"   Output: {config['num_classes']} neurons (Control vs Pathological)")

    print("\nHYPERPARAMETERS:")
    print(f"   Optimizer: {best_genome['optimizer'].upper()}")
    print(f"   Learning Rate: {best_genome['learning_rate']:.6f}")
    print(f"   Dropout Rate: {best_genome['dropout_rate']:.3f}")
    print(f"   Activation Functions: {', '.join(set(best_genome['activations']))}")

    print("\nCREATING FINAL MODEL...")
    try:
        final_model = EvolvableCNN(best_genome, config)
        total_params = sum(p.numel() for p in final_model.parameters())
        trainable_params = sum(p.numel() for p in final_model.parameters() if p.requires_grad)

        print("   Model created successfully")
        print(f"   Total parameters: {total_params:,}")
        print(f"   Trainable parameters: {trainable_params:,}")
        print(f"   Model size: ~{total_params * 4 / 1024 / 1024:.2f} MB (float32)")

        print("\nCOMPACT SUMMARY:")
        print(f"   {final_model.get_architecture_summary()}")

    except Exception as e:
        print(f"   ERROR creating model: {e}")

    print("\nSUMMARY TABLE:")
    print(f"{'='*80}")
    print(f"{'Parameter':<25} {'Value':<30} {'Description':<25}")
    print(f"{'='*80}")
    print(f"{'ID':<25} {best_genome['id']:<30} {'Unique identifier':<25}")
    print(f"{'Fitness':<25} {best_genome['fitness']:.2f}%{'':<25} {'Validation fitness':<25}")
    print(f"{'Architecture':<25} {_format_architecture(best_genome):<30} {f'{dimension} Convolutional':<25}")
    if best_genome.get("architecture_template_id"):
        print(f"{'Template':<25} {best_genome.get('architecture_template_id'):<30} {'Known architecture seed':<25}")
        print(f"{'Template Family':<25} {best_genome.get('architecture_template_family', 'N/A'):<30} {'Template lineage':<25}")
    print(f"{'Conv Layers':<25} {best_genome['num_conv_layers']:<30} {f'Conv{dimension} layers':<25}")
    print(f"{'Residual':<25} {str(best_genome.get('residual_enabled', False)):<30} {f'Residual Conv{dimension} blocks':<25}")
    if best_genome.get("residual_enabled", False):
        print(f"{'Residual Block Size':<25} {best_genome.get('residual_block_size', 2):<30} {'Conv units per block':<25}")
        print(f"{'Residual Projection':<25} {best_genome.get('residual_projection', 'auto'):<30} {'Shortcut projection':<25}")
    print(f"{'Inception':<25} {str(best_genome.get('inception_enabled', False)):<30} {f'Inception Conv{dimension} modules':<25}")
    if best_genome.get("inception_enabled", False):
        print(f"{'Inception Reduction':<25} {best_genome.get('inception_reduction_ratio', 0.5):<30} {'1x1 reduction ratio':<25}")
        print(f"{'Inception Pool Branch':<25} {str(best_genome.get('inception_pool_branch', True)):<30} {'Pooling branch':<25}")
    print(f"{'FC Layers':<25} {best_genome['num_fc_layers']:<30} {'FC layers':<25}")
    print(f"{'Optimizer':<25} {best_genome['optimizer']:<30} {'Optimization algorithm':<25}")
    print(f"{'Learning Rate':<25} {best_genome['learning_rate']:<30.6f} {'Learning rate':<25}")
    print(f"{'Dropout':<25} {best_genome['dropout_rate']:<30} {'Dropout rate':<25}")
    input_length_label = 'Spectrogram time frames' if is_spectrogram else 'Audio sequence length'
    print(f"{'Input Length':<25} {config['sequence_length']:<30} {input_length_label:<25}")
    print(f"{'Classes':<25} {config['num_classes']:<30} {'Binary classification':<25}")
    print(f"{'='*80}")

    print("\nCOMPARISON WITH OBJECTIVES:")
    if best_genome["fitness"] >= config["fitness_threshold"]:
        print(f"   ✓ TARGET REACHED: {best_genome['fitness']:.2f}% >= {config['fitness_threshold']}%")
    else:
        print(f"   ✗ TARGET NOT REACHED: {best_genome['fitness']:.2f}% < {config['fitness_threshold']}%")
        print(f"     Gap: {config['fitness_threshold'] - best_genome['fitness']:.2f}%")

    print(f"   Generations used: {neuroevolution.generation}/{config['max_generations']}")

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    results_file = os.path.join(config['artifacts_dir'], f"best_architecture_{data_name}_{timestamp}.json")

    results_data = {
        "timestamp": timestamp,
        "execution_time": str(execution_time),
        "dataset_type": f"{data_name}_{dimension}",
        "dataset_id": config.get("dataset_id", "N/A"),
        "fold": config.get("current_fold", "N/A"),
        "config_used": {k: v for k, v in config.items() if not k.startswith("_")},
        "best_genome": best_genome,
        "final_generation": neuroevolution.generation,
        "evolution_stats": neuroevolution.generation_stats,
    }

    try:
        with open(results_file, "w", encoding="utf-8") as f:
            json.dump(results_data, f, indent=2, default=str)
        print(f"\n✓ Results saved to: {results_file}")
    except Exception as e:
        print(f"\n✗ WARNING: Error saving results: {e}")

    print(f"\n{'='*60}")
    print(f"HYBRID NEUROEVOLUTION FOR {data_name.upper()} COMPLETED!")
    print(f"{'='*60}")


def print_checkpoint_info(neuroevolution, device: torch.device) -> None:
    """
    Print summary information for the currently saved best checkpoint.

    Args:
        neuroevolution: HybridNeuroevolution instance.
        device: Device used to load checkpoint metadata.
    """
    print("=" * 80)
    print("INFORMACIÓN DEL CHECKPOINT DEL MEJOR MODELO")
    print("=" * 80)

    if neuroevolution.best_checkpoint_path:
        print(f"\n✓ Checkpoint guardado en: {neuroevolution.best_checkpoint_path}")

        if os.path.exists(neuroevolution.best_checkpoint_path):
            file_size = os.path.getsize(neuroevolution.best_checkpoint_path)
            file_size_mb = file_size / (1024 * 1024)
            print(f"  Tamaño: {file_size_mb:.2f} MB")

            checkpoint_data = torch.load(neuroevolution.best_checkpoint_path, map_location=device, weights_only=False)
            print("\n  Información del modelo guardado:")
            print(f"    Generación: {checkpoint_data['generation']}")
            print(f"    Fitness: {checkpoint_data['fitness']:.2f}%")
            print(f"    ID Genoma: {checkpoint_data['genome']['id']}")
            print(
                f"    Arquitectura: {_format_architecture(checkpoint_data['genome'])}"
            )
            if checkpoint_data['genome'].get('architecture_template_id'):
                print(f"    Template: {checkpoint_data['genome'].get('architecture_template_id')}")
                print(f"    Template Family: {checkpoint_data['genome'].get('architecture_template_family', 'N/A')}")
                print(f"    Template Origin: {checkpoint_data['genome'].get('architecture_template_origin', 'N/A')}")
            print(f"    Residual: {checkpoint_data['genome'].get('residual_enabled', False)}")
            if checkpoint_data['genome'].get('residual_enabled', False):
                print(f"    Residual Block Size: {checkpoint_data['genome'].get('residual_block_size', 2)}")
                print(f"    Residual Projection: {checkpoint_data['genome'].get('residual_projection', 'auto')}")
            print(f"    Inception: {checkpoint_data['genome'].get('inception_enabled', False)}")
            if checkpoint_data['genome'].get('inception_enabled', False):
                print(f"    Inception Reduction Ratio: {checkpoint_data['genome'].get('inception_reduction_ratio', 0.5)}")
                print(f"    Inception Pool Branch: {checkpoint_data['genome'].get('inception_pool_branch', True)}")
            print(f"    Optimizador: {checkpoint_data['genome']['optimizer']}")
            print(f"    Learning Rate: {checkpoint_data['genome']['learning_rate']}")

            print("\n  Este checkpoint fue seleccionado por validación durante la evolución")
            print("  Para métricas finales, reentrenar por fold y evaluar solo en test")
        else:
            print("  ✗ Archivo no encontrado")
    else:
        print("\n✗ No hay checkpoint disponible")
        print("  La evaluación final de 5 folds entrenará desde cero")

    print("\n" + "=" * 80)
