"""
Evolution engine module - main HybridNeuroevolution class.

This module implements the core evolution loop with:
- Population initialization with incremental complexity growth
- Genetic speciation based on compatibility distance
- Adaptive mutation rates based on population diversity
- Elitism and fitness-proportional selection
- Generation-level early stopping
- Checkpoint management and progress tracking
"""

import os
import copy
import random
import uuid
import json
import numpy as np
import torch
import torch.nn as nn
from typing import Dict, Optional

from ..genetics.genome import create_random_genome
from ..genetics.mutation import mutate_genome
from ..genetics.crossover import crossover_genomes
from ..genetics.innovation import build_innovation_genes, append_structural_event
from ..models.genome_validator import calculate_max_safe_conv_layers, validate_and_fix_genome
from ..models.evolvable_cnn import EvolvableCNN
from .fitness import evaluate_fitness


class HybridNeuroevolution:
    """Main class that implements hybrid neuroevolution with 5-fold CV and adaptive mutation."""

    def __init__(self, config: dict, device: torch.device):
        self.config = config
        self.device = device
        self.population = []
        self.generation = 0
        self.best_individual = None
        self.fitness_history = []
        self.generation_stats = []

        self.run_artifacts_dir = self.config.get('artifacts_dir', 'artifacts/test_audio')
        os.makedirs(self.run_artifacts_dir, exist_ok=True)
        self.best_checkpoint_path = None
        self.progress_json_path = os.path.join(self.run_artifacts_dir, 'evolution_progress.json')
        self.generation_log_path = os.path.join(self.run_artifacts_dir, 'generation_progress.txt')

        # Early stopping configuration at generation level
        self.generations_without_improvement = 0
        self.best_fitness_overall = -float('inf')
        self.best_fitness_for_early_stopping = -float('inf')
        self.min_improvement_threshold = config.get('min_improvement_threshold', 0.1)
        self.max_generations_without_improvement = config.get('early_stopping_generations', 10)

        # Incremental evolution defaults
        self.config.setdefault('complexity_step_generations', 3)
        self.config.setdefault('initial_max_conv_layers', self.config['min_conv_layers'])
        self.config.setdefault('initial_max_fc_layers', self.config['min_fc_layers'])
        self.config.setdefault('incremental_growth_probability', 0.7)

        # Genetic speciation defaults
        self.config.setdefault('speciation_threshold', 0.45)
        self.config.setdefault('species_elite_min', 1)
        self.config.setdefault('species_survival_rate', 0.5)

        self.config['current_max_conv_layers'] = self.config['initial_max_conv_layers']
        self.config['current_max_fc_layers'] = self.config['initial_max_fc_layers']

        self.species = {}

    def _append_generation_log(self, text: str):
        """Appends text to generation log file."""
        with open(self.generation_log_path, 'a', encoding='utf-8') as log_file:
            log_file.write(text + "\n")

    def _to_json_serializable(self, value):
        """Converts numpy types to JSON-serializable Python types."""
        if isinstance(value, dict):
            return {k: self._to_json_serializable(v) for k, v in value.items()}
        if isinstance(value, list):
            return [self._to_json_serializable(v) for v in value]
        if isinstance(value, np.generic):
            return value.item()
        return value

    def _save_evolution_progress(self):
        """Saves current evolution state to JSON file."""
        progress_data = {
            'generation': self.generation,
            'population': self._to_json_serializable(self.population),
            'best_individual': self._to_json_serializable(self.best_individual),
            'fitness_history': self._to_json_serializable(self.fitness_history),
            'generation_stats': self._to_json_serializable(self.generation_stats),
            'generations_without_improvement': self.generations_without_improvement,
            'best_fitness_overall': self.best_fitness_overall,
            'best_fitness_for_early_stopping': self.best_fitness_for_early_stopping,
            'best_checkpoint_path': self.best_checkpoint_path
        }

        with open(self.progress_json_path, 'w', encoding='utf-8') as progress_file:
            json.dump(progress_data, progress_file, indent=2)

    def _load_evolution_progress(self) -> bool:
        """Loads evolution state from JSON file if exists."""
        if not os.path.exists(self.progress_json_path):
            return False

        try:
            with open(self.progress_json_path, 'r', encoding='utf-8') as progress_file:
                progress_data = json.load(progress_file)

            self.generation = int(progress_data.get('generation', 0))
            self.population = progress_data.get('population', [])
            self.best_individual = progress_data.get('best_individual', None)
            self.fitness_history = progress_data.get('fitness_history', [])
            self.generation_stats = progress_data.get('generation_stats', [])
            self.generations_without_improvement = int(progress_data.get('generations_without_improvement', 0))
            self.best_fitness_overall = float(progress_data.get('best_fitness_overall', -float('inf')))
            self.best_fitness_for_early_stopping = float(
                progress_data.get('best_fitness_for_early_stopping', self.best_fitness_overall)
            )
            self.best_checkpoint_path = progress_data.get('best_checkpoint_path', None)
            return True
        except Exception as e:
            print(f"WARNING: Could not load evolution progress: {e}")
            return False

    def _update_incremental_complexity(self):
        """Updates complexity caps based on current generation."""
        step = max(1, self.config['complexity_step_generations'])
        stage = max(0, self.generation // step)

        self.config['current_max_conv_layers'] = min(
            self.config['max_conv_layers'],
            self.config['initial_max_conv_layers'] + stage
        )
        self.config['current_max_fc_layers'] = min(
            self.config['max_fc_layers'],
            self.config['initial_max_fc_layers'] + stage
        )

    def _enforce_complexity_caps(self, genome: dict) -> dict:
        """Enforces incremental complexity caps on a genome."""
        genome['num_conv_layers'] = min(genome['num_conv_layers'], self.config['current_max_conv_layers'])
        genome['num_fc_layers'] = min(genome['num_fc_layers'], self.config['current_max_fc_layers'])
        genome = validate_and_fix_genome(genome, self.config)
        genome['innovation_genes'] = build_innovation_genes(genome)
        return genome

    def _max_safe_conv_layers_for_genome(self, genome: dict) -> int:
        """Returns safe conv depth for a genome's current topology."""
        fixed = validate_and_fix_genome(copy.deepcopy(genome), self.config)
        return calculate_max_safe_conv_layers(
            self.config['sequence_length'],
            min_required_length=4,
            residual_enabled=fixed.get('residual_enabled', False),
            residual_block_size=fixed.get('residual_block_size', 2),
            inception_enabled=fixed.get('inception_enabled', False),
        )

    def _create_double_cap_individual(self) -> dict:
        """Creates one individual using doubled layer caps for the current generation."""
        base_conv_cap = max(
            self.config['min_conv_layers'],
            self.config.get('current_max_conv_layers', self.config['max_conv_layers'])
        )
        base_fc_cap = max(
            self.config['min_fc_layers'],
            self.config.get('current_max_fc_layers', self.config['max_fc_layers'])
        )

        target_conv_layers = min(self.config['max_conv_layers'], base_conv_cap * 2)
        target_fc_layers = min(self.config['max_fc_layers'], base_fc_cap * 2)

        target_fc_layers = max(self.config['min_fc_layers'], target_fc_layers)

        boosted_config = copy.deepcopy(self.config)
        boosted_config['current_max_conv_layers'] = target_conv_layers
        boosted_config['current_max_fc_layers'] = target_fc_layers

        genome = create_random_genome(boosted_config)
        max_safe_conv_layers = self._max_safe_conv_layers_for_genome(genome)
        target_conv_layers = max(
            self.config['min_conv_layers'],
            min(target_conv_layers, max_safe_conv_layers)
        )
        genome['num_conv_layers'] = target_conv_layers
        genome['num_fc_layers'] = target_fc_layers
        genome = validate_and_fix_genome(genome, boosted_config)
        genome['innovation_genes'] = build_innovation_genes(genome)
        genome['id'] = str(uuid.uuid4())[:8]
        genome['fitness'] = 0.0

        append_structural_event(
            genome,
            'double_cap_seed',
            {
                'base_conv_cap': int(base_conv_cap),
                'base_fc_cap': int(base_fc_cap),
                'target_conv_layers': int(genome['num_conv_layers']),
                'target_fc_layers': int(genome['num_fc_layers'])
            }
        )
        return genome

    def _active_topology(self, genome: dict) -> str:
        """Returns the active Conv1D topology name."""
        if genome.get('inception_enabled', False):
            return 'inception'
        if genome.get('residual_enabled', False):
            return 'residual'
        return 'sequential'

    def _conv_topology_distance(self, g1: dict, g2: dict) -> float:
        """Returns a normalized distance for sequential/residual/Inception topology."""
        topology1 = self._active_topology(g1)
        topology2 = self._active_topology(g2)
        topology_distance = 0.0 if topology1 == topology2 else 1.0

        block_options = self.config.get('residual_block_size_options', [2, 3])
        block_span = max(1, max(block_options) - min(block_options)) if block_options else 1
        block_distance = abs(
            int(g1.get('residual_block_size', 2)) - int(g2.get('residual_block_size', 2))
        ) / block_span
        projection_distance = 0.0 if str(g1.get('residual_projection', 'auto')) == str(g2.get('residual_projection', 'auto')) else 1.0
        residual_distance = (min(1.0, block_distance) + projection_distance) / 2.0 if topology1 == topology2 == 'residual' else 0.0

        reduction_options = self.config.get('inception_reduction_ratio_options', [0.25, 0.5])
        reduction_span = max(1e-8, max(reduction_options) - min(reduction_options)) if reduction_options else 1.0
        reduction_distance = abs(
            float(g1.get('inception_reduction_ratio', 0.5)) - float(g2.get('inception_reduction_ratio', 0.5))
        ) / reduction_span
        pool_distance = 0.0 if bool(g1.get('inception_pool_branch', True)) == bool(g2.get('inception_pool_branch', True)) else 1.0
        inception_distance = (min(1.0, reduction_distance) + pool_distance) / 2.0 if topology1 == topology2 == 'inception' else 0.0
        return (topology_distance + residual_distance + inception_distance) / 3.0

    def _format_architecture(self, genome: dict) -> str:
        """Formats architecture topology for logs and cached generation summaries."""
        base = f"{genome['num_conv_layers']}conv+{genome['num_fc_layers']}fc"
        if genome.get('inception_enabled', False):
            return f"{base}+inc"
        if genome.get('residual_enabled', False):
            return f"{base}+res{genome.get('residual_block_size', 2)}"
        return base

    def compatibility_distance(self, g1: dict, g2: dict) -> float:
        """Combines topology differences and innovation mismatch for speciation."""
        topo = (
            abs(g1['num_conv_layers'] - g2['num_conv_layers']) +
            abs(g1['num_fc_layers'] - g2['num_fc_layers'])
        ) / max(1, self.config['max_conv_layers'] + self.config['max_fc_layers'])

        ids1 = {gene['innovation_id'] for gene in g1.get('innovation_genes', [])}
        ids2 = {gene['innovation_id'] for gene in g2.get('innovation_genes', [])}
        union_size = len(ids1 | ids2)
        innovation_mismatch = 0.0 if union_size == 0 else 1.0 - (len(ids1 & ids2) / union_size)

        numeric = (
            abs(g1.get('dropout_rate', 0.0) - g2.get('dropout_rate', 0.0)) +
            abs(np.log10(g1.get('learning_rate', 1e-4)) - np.log10(g2.get('learning_rate', 1e-4))) / 4.0
        ) / 2.0

        conv_topology = self._conv_topology_distance(g1, g2)

        return 0.40 * topo + 0.40 * innovation_mismatch + 0.10 * conv_topology + 0.10 * numeric

    def _speciate_population(self):
        """Assigns genomes to species based on compatibility distance."""
        self.species = {}
        threshold = self.config['speciation_threshold']

        for genome in self.population:
            genome['innovation_genes'] = build_innovation_genes(genome)
            assigned = False

            for species_id, specie in self.species.items():
                distance = self.compatibility_distance(genome, specie['representative'])
                if distance <= threshold:
                    specie['members'].append(genome)
                    genome['species_id'] = species_id
                    assigned = True
                    break

            if not assigned:
                species_id = f"S{len(self.species) + 1}"
                self.species[species_id] = {
                    'representative': genome,
                    'members': [genome]
                }
                genome['species_id'] = species_id

    def initialize_population(self):
        """Initializes population or resumes from saved progress."""
        if self._load_evolution_progress():
            self._update_incremental_complexity()
            print(f"Resuming evolution from generation {self.generation} using: {self.progress_json_path}")
            return

        with open(self.generation_log_path, 'w', encoding='utf-8') as log_file:
            log_file.write("Generation progress log\n")

        self._update_incremental_complexity()
        print(f"Initializing population of {self.config['population_size']} individuals...")
        print(
            f"Incremental caps at generation {self.generation}: "
            f"conv<={self.config['current_max_conv_layers']}, fc<={self.config['current_max_fc_layers']}"
        )
        print("Using mixed quartile initialization for initial population depth ranges.")

        reserve_double_cap_slot = self.config['population_size'] > 1
        regular_population_size = (
            self.config['population_size'] - 1
            if reserve_double_cap_slot
            else self.config['population_size']
        )

        self.population = []
        min_conv_layers = int(self.config['min_conv_layers'])
        min_fc_layers = int(self.config['min_fc_layers'])

        for i in range(regular_population_size):
            # Quartiles: Q1 -> 25% of max depth caps, Q2 -> 50%, Q3 -> 75%, Q4 -> 100%.
            quartile_index = min(3, (4 * i) // max(1, regular_population_size))
            quartile_number = quartile_index + 1

            conv_quartile_cap = int(np.ceil((quartile_number / 4.0) * self.config['max_conv_layers']))
            fc_quartile_cap = int(np.ceil((quartile_number / 4.0) * self.config['max_fc_layers']))

            conv_quartile_cap = max(min_conv_layers, conv_quartile_cap)
            fc_quartile_cap = max(min_fc_layers, fc_quartile_cap)

            quartile_config = copy.deepcopy(self.config)
            quartile_config['current_max_conv_layers'] = conv_quartile_cap
            quartile_config['current_max_fc_layers'] = fc_quartile_cap

            genome = create_random_genome(quartile_config)
            genome_safe_max_conv_layers = self._max_safe_conv_layers_for_genome(genome)
            genome_quartile_cap = max(min_conv_layers, min(conv_quartile_cap, genome_safe_max_conv_layers))

            # Force layer counts to remain inside the quartile range requested by the user.
            genome['num_conv_layers'] = random.randint(min_conv_layers, genome_quartile_cap)
            genome['num_fc_layers'] = random.randint(min_fc_layers, fc_quartile_cap)
            genome = validate_and_fix_genome(genome, quartile_config)
            genome['innovation_genes'] = build_innovation_genes(genome)

            append_structural_event(
                genome,
                'quartile_init',
                {
                    'index_in_population': i,
                    'quartile': quartile_number,
                    'conv_cap': genome_quartile_cap,
                    'fc_cap': fc_quartile_cap,
                    'num_conv_layers': int(genome['num_conv_layers']),
                    'num_fc_layers': int(genome['num_fc_layers'])
                }
            )

            genome['id'] = str(uuid.uuid4())[:8]
            genome['fitness'] = 0.0
            self.population.append(genome)

        if reserve_double_cap_slot:
            self.population.append(self._create_double_cap_individual())

        print(f"Population initialized with {len(self.population)} individuals")

    def save_best_checkpoint(self, genome: dict, model: nn.Module):
        """
        Guarda el checkpoint del mejor modelo global y elimina el anterior.

        Args:
            genome: Genoma del mejor modelo
            model: Modelo de PyTorch a guardar
        """
        checkpoint_dir = self.run_artifacts_dir
        os.makedirs(checkpoint_dir, exist_ok=True)

        if self.best_checkpoint_path and os.path.exists(self.best_checkpoint_path):
            try:
                os.remove(self.best_checkpoint_path)
                print(f"      Checkpoint anterior eliminado: {self.best_checkpoint_path}")
            except Exception as e:
                print(f"      Error eliminando checkpoint anterior: {e}")

        checkpoint_filename = f"best_model_gen{self.generation}_id{genome['id']}_fitness{genome['fitness']:.2f}.pth"
        checkpoint_path = os.path.join(checkpoint_dir, checkpoint_filename)

        checkpoint_data = {
            'model_state_dict': model.state_dict(),
            'genome': genome,
            'generation': self.generation,
            'fitness': genome['fitness'],
            'config': self.config
        }

        try:
            torch.save(checkpoint_data, checkpoint_path)
            self.best_checkpoint_path = checkpoint_path
            self._save_evolution_progress()
            print(f"      Nuevo checkpoint guardado: {checkpoint_path}")
            print(f"        Fitness: {genome['fitness']:.2f}%, ID: {genome['id']}, Gen: {self.generation}")
        except Exception as e:
            print(f"      Error guardando checkpoint: {e}")

    def load_best_checkpoint(self) -> tuple:
        """
        Carga el mejor checkpoint guardado.

        Returns:
            Tuple de (genome, model) o (None, None) si no hay checkpoint
        """
        if not self.best_checkpoint_path or not os.path.exists(self.best_checkpoint_path):
            print("No hay checkpoint disponible para cargar")
            return None, None

        try:
            checkpoint_data = torch.load(self.best_checkpoint_path, map_location=self.device, weights_only=False)
            genome = checkpoint_data['genome']

            model = EvolvableCNN(genome, self.config).to(self.device)
            model.load_state_dict(checkpoint_data['model_state_dict'])

            print(f"Checkpoint cargado exitosamente: {self.best_checkpoint_path}")
            print(f"  Fitness: {checkpoint_data['fitness']:.2f}%, Gen: {checkpoint_data['generation']}, ID: {genome['id']}")
            print(f"  Architecture: {self._format_architecture(genome)}")

            return genome, model
        except Exception as e:
            print(f"Error cargando checkpoint: {e}")
            return None, None

    def evaluate_population(self):
        """Evaluates all individuals in the population and tracks statistics."""
        print(f"\nEvaluating population (Generation {self.generation})...")
        print(f"Processing {len(self.population)} individuals...")

        fitness_scores = []
        all_individual_metrics = []
        best_fitness_so_far = 0.0
        current_global_best_fitness = self.best_individual['fitness'] if self.best_individual else 0.0
        generation_log_lines = []

        for i, genome in enumerate(self.population):
            print(
                f"   Evaluating individual {i+1}/{len(self.population)} (ID: {genome['id']})"
            )
            print(
                f"      Architecture: {self._format_architecture(genome)}, "
                f"optimizer={genome['optimizer']}, learning_rate={genome['learning_rate']}"
            )

            skip_evaluation = bool(genome.pop('skip_next_evaluation', False))
            cached_metrics = genome.get('metrics')
            if skip_evaluation and cached_metrics is not None:
                fitness = float(genome.get('fitness', 0.0))
                metrics = cached_metrics
                model = None
                evaluation_status = 'cached_elite'
                cached_from_generation = genome.pop('cached_from_generation', self.generation - 1)
                print(
                    f"      Skipping training: elite selected in generation {cached_from_generation} "
                    f"keeps cached fitness {fitness:.2f}%"
                )
            else:
                genome.pop('cached_from_generation', None)
                fitness, model, metrics = evaluate_fitness(genome, self.config, self.device)
                genome['fitness'] = fitness
                genome['metrics'] = metrics
                evaluation_status = 'trained'

            fitness_scores.append(fitness)

            individual_summary = {
                'id': genome['id'],
                'fitness': fitness,
                'architecture': self._format_architecture(genome),
                'optimizer': genome['optimizer'],
                'lr': genome['learning_rate'],
                'metrics': metrics,
                'evaluation_status': evaluation_status
            }
            all_individual_metrics.append(individual_summary)

            if fitness > best_fitness_so_far:
                best_fitness_so_far = fitness

            if fitness > current_global_best_fitness:
                current_global_best_fitness = fitness
                if model is not None:
                    self.save_best_checkpoint(genome, model)

            generation_log_lines.append(
                f"Individual {i+1}/{len(self.population)} | ID={genome['id']} | "
                f"status={evaluation_status} | fitness={fitness:.2f}% | "
                f"best_gen={best_fitness_so_far:.2f}% | global_best={current_global_best_fitness:.2f}%"
            )

        if fitness_scores:
            avg_fitness = np.mean(fitness_scores)
            max_fitness = np.max(fitness_scores)
            min_fitness = np.min(fitness_scores)
            std_fitness = np.std(fitness_scores)
        else:
            avg_fitness = max_fitness = min_fitness = std_fitness = 0.0

        stats = {
            'generation': self.generation,
            'avg_fitness': avg_fitness,
            'max_fitness': max_fitness,
            'min_fitness': min_fitness,
            'std_fitness': std_fitness,
            'individual_metrics': all_individual_metrics
        }
        self.generation_stats.append(stats)
        self.fitness_history.append(max_fitness)

        best_genome = max(self.population, key=lambda x: x['fitness'])
        if self.best_individual is None or best_genome['fitness'] > self.best_individual['fitness']:
            self.best_individual = copy.deepcopy(best_genome)

        if self.best_individual is not None:
            self.best_fitness_overall = max(self.best_fitness_overall, self.best_individual['fitness'])

        sorted_individuals = sorted(all_individual_metrics, key=lambda x: x['fitness'], reverse=True)

        generation_log_lines.append("=" * 100)
        generation_log_lines.append(f"GENERATION {self.generation} - DETAILED METRICS SUMMARY")
        generation_log_lines.append("=" * 100)
        generation_log_lines.append(f"{'ID':<15} {'Arch':<24} {'Acc':<10} {'Sen':<10} {'Spe':<10} {'Pre':<10} {'F1':<10} {'AUC':<10}")
        generation_log_lines.append("-" * 100)

        for ind in sorted_individuals:
            m = ind['metrics']
            generation_log_lines.append(
                f"{ind['id'][:13]:<15} {ind['architecture']:<24} "
                f"{m['accuracy']:>6.2f}%   {m['sensitivity']:>6.2f}%   "
                f"{m['specificity']:>6.2f}%   {m['precision']:>6.2f}%   "
                f"{m['f1_score']:>6.2f}%   {m['auc']:>6.2f}%"
            )

        generation_log_lines.append("-" * 100)

        valid_metrics = [ind['metrics'] for ind in all_individual_metrics if ind['metrics']['n_valid_folds'] > 0]
        if valid_metrics:
            gen_avg_acc = np.mean([m['accuracy'] for m in valid_metrics])
            gen_avg_sen = np.mean([m['sensitivity'] for m in valid_metrics])
            gen_avg_spe = np.mean([m['specificity'] for m in valid_metrics])
            gen_avg_pre = np.mean([m['precision'] for m in valid_metrics])
            gen_avg_f1 = np.mean([m['f1_score'] for m in valid_metrics])
            gen_avg_auc = np.mean([m['auc'] for m in valid_metrics])

            generation_log_lines.append(
                f"{'GENERATION AVG':<15} {'':<15} "
                f"{gen_avg_acc:>6.2f}%   {gen_avg_sen:>6.2f}%   "
                f"{gen_avg_spe:>6.2f}%   {gen_avg_pre:>6.2f}%   "
                f"{gen_avg_f1:>6.2f}%   {gen_avg_auc:>6.2f}%"
            )

        generation_log_lines.append("-" * 100)
        generation_log_lines.append(f"GENERATION {self.generation} STATISTICS:")
        generation_log_lines.append(f"   Maximum fitness: {max_fitness:.2f}%")
        generation_log_lines.append(f"   Average fitness: {avg_fitness:.2f}%")
        generation_log_lines.append(f"   Minimum fitness: {min_fitness:.2f}%")
        generation_log_lines.append(f"   Standard deviation: {std_fitness:.2f}%")
        generation_log_lines.append(f"   Best individual: {best_genome['id']} with {best_genome['fitness']:.2f}%")
        generation_log_lines.append(f"   Global best individual: {self.best_individual['id']} with {self.best_individual['fitness']:.2f}%")

        if best_genome.get('metrics'):
            bm = best_genome['metrics']
            generation_log_lines.append(f"   Best Individual Metrics (ID: {best_genome['id']}):")
            generation_log_lines.append(f"      Accuracy:     {bm['accuracy']:.2f}% +/- {bm['accuracy_std']:.2f}%")
            generation_log_lines.append(f"      Sensitivity:  {bm['sensitivity']:.2f}% +/- {bm['sensitivity_std']:.2f}%")
            generation_log_lines.append(f"      Specificity:  {bm['specificity']:.2f}% +/- {bm['specificity_std']:.2f}%")
            generation_log_lines.append(f"      Precision:    {bm['precision']:.2f}% +/- {bm['precision_std']:.2f}%")
            generation_log_lines.append(f"      F1-Score:     {bm['f1_score']:.2f}% +/- {bm['f1_score_std']:.2f}%")
            generation_log_lines.append(f"      AUC:          {bm['auc']:.2f}% +/- {bm['auc_std']:.2f}%")

        generation_log_lines.append("=" * 100)

        self._append_generation_log("\n".join(generation_log_lines))

        print(
            f"Generation {self.generation} summary -> "
            f"max: {max_fitness:.2f}% | avg: {avg_fitness:.2f}% | min: {min_fitness:.2f}% | std: {std_fitness:.2f}%"
        )
        print(f"Detailed generation report appended to: {self.generation_log_path}")

    def selection_and_reproduction(self):
        """Selects best individuals and creates new generation through crossover and mutation."""
        print(f"\nStarting selection and reproduction...")
        self.config['current_generation'] = self.generation
        
        # Sort by fitness
        self.population.sort(key=lambda x: x['fitness'], reverse=True)
        reserve_double_cap_slot = self.config['population_size'] > 1
        regular_target_size = (
            self.config['population_size'] - 1
            if reserve_double_cap_slot
            else self.config['population_size']
        )

        elite_size = max(1, int(self.config['population_size'] * self.config['elite_percentage']))
        elite_size = min(elite_size, regular_target_size)
        elite = []
        
        print(f"Selecting {elite_size} elite individuals:")
        for i, individual in enumerate(self.population[:elite_size]):
            print(f"   Elite {i+1}: {individual['id']} (fitness: {individual['fitness']:.2f}%)")
            elite_individual = copy.deepcopy(individual)
            elite_individual['skip_next_evaluation'] = True
            elite_individual['cached_from_generation'] = self.generation
            elite.append(elite_individual)
        
        new_population = elite
        offspring_needed = regular_target_size - len(new_population)
        
        print(f"Creating {offspring_needed} new individuals through crossover and mutation...")
        offspring_created = 0
        
        while len(new_population) < regular_target_size:
            parent1 = self.tournament_selection()
            parent2 = self.tournament_selection()
            child1, child2 = crossover_genomes(parent1, parent2, self.config)
            child1 = mutate_genome(child1, self.config)
            
            if len(new_population) < regular_target_size:
                new_population.append(child1)
            
            child2 = mutate_genome(child2, self.config)
            if len(new_population) < regular_target_size:
                new_population.append(child2)
            
            offspring_created += 2
            if offspring_created % 4 == 0:
                print(f"   Created {min(offspring_created, offspring_needed)} of {offspring_needed} new individuals...")
        
        self.population = new_population[:regular_target_size]
        if reserve_double_cap_slot:
            self.population.append(self._create_double_cap_individual())
        
        print(f"New generation created with {len(self.population)} individuals")
        print(f"   Elite preserved: {elite_size}")
        print(f"   New individuals: {len(self.population) - elite_size}")

    def tournament_selection(self, tournament_size: int = 3) -> dict:
        """Selects best individual from a random tournament."""
        tournament = random.sample(self.population, min(tournament_size, len(self.population)))
        return max(tournament, key=lambda x: x['fitness'])

    def _update_adaptive_mutation(self):
        """Updates mutation rate based on population diversity."""
        if not self.generation_stats:
            self.config['current_mutation_rate'] = self.config['base_mutation_rate']
            return
        
        last_std = self.generation_stats[-1]['std_fitness']
        diversity_factor = min(1.0, last_std / 10.0)
        inverted = 1 - diversity_factor
        new_rate = self.config['base_mutation_rate'] + (inverted - 0.5) * 0.4
        new_rate = max(self.config['mutation_rate_min'], min(self.config['mutation_rate_max'], new_rate))
        self.config['current_mutation_rate'] = round(new_rate, 4)
        
        print(f"Adaptive mutation rate updated to {self.config['current_mutation_rate']} (std_fitness={last_std:.2f})")

    def check_convergence(self) -> bool:
        """
        Verifica criterios de convergencia:
        1. Target fitness alcanzado
        2. Máximo de generaciones alcanzado
        3. Early stopping: sin mejora en N generaciones
        4. Estancamiento detectado en últimas generaciones
        """
        # Criterion 1: Target fitness reached
        if self.best_individual and self.best_individual['fitness'] >= self.config['fitness_threshold']:
            print(f"\n✅ Target fitness reached! ({self.best_individual['fitness']:.2f}% >= {self.config['fitness_threshold']}%)")
            return True
        
        # Criterion 2: Maximum generations reached
        if self.generation >= self.config['max_generations']:
            print(f"\n⏱️ Maximum generations reached ({self.generation}/{self.config['max_generations']})")
            return True
        
        # Criterion 3: Early stopping - no improvement in N generations
        if self.generation > 0:
            current_best = self.best_individual['fitness'] if self.best_individual else 0.0
            improvement = current_best - self.best_fitness_for_early_stopping
            
            if improvement >= self.min_improvement_threshold:
                self.best_fitness_for_early_stopping = current_best
                self.generations_without_improvement = 0
                print(f"\n🔄 Improvement detected: {improvement:.2f}% | Generations without improvement: {self.generations_without_improvement}")
            else:
                self.generations_without_improvement += 1
                print(f"\n⏳ No significant improvement | Generations without improvement: {self.generations_without_improvement}/{self.max_generations_without_improvement}")
                
                if self.generations_without_improvement >= self.max_generations_without_improvement:
                    print(f"\n🛑 EARLY STOPPING: No improvement for {self.max_generations_without_improvement} generations")
                    print(f"   Best fitness plateau: {self.best_fitness_overall:.2f}%")
                    return True
        
        # Criterion 4: Stagnation in last 3 generations
        if len(self.fitness_history) >= 3:
            recent = self.fitness_history[-3:]
            if max(recent) - min(recent) < 0.5:
                print(f"\n📉 Stagnation detected in last 3 generations (all within {max(recent) - min(recent):.2f}%)")
        
        return False

    def _print_final_metrics_summary(self):
        """Imprime un resumen detallado de las métricas del mejor individuo encontrado."""
        print(f"\n{'#'*100}")
        print(f"{'#'*35} FINAL BEST INDIVIDUAL SUMMARY {'#'*34}")
        print(f"{'#'*100}")
        
        best = self.best_individual
        print(f"\n🏆 BEST INDIVIDUAL DETAILS:")
        print(f"   ID: {best['id']}")
        print(f"   Architecture: {self._format_architecture(best)}")
        print(f"   Residual Enabled: {best.get('residual_enabled', False)}")
        if best.get('residual_enabled', False):
            print(f"   Residual Block Size: {best.get('residual_block_size', 2)}")
            print(f"   Residual Projection: {best.get('residual_projection', 'auto')}")
        print(f"   Optimizer: {best['optimizer']}")
        print(f"   Learning Rate: {best['learning_rate']}")
        print(f"   Fitness: {best['fitness']:.2f}%")
        
        if best.get('metrics'):
            m = best['metrics']
            print(f"\n📊 PERFORMANCE METRICS (5-Fold Cross-Validation):")
            print(f"   {'─'*60}")
            print(f"   {'Metric':<15} {'Mean':<15} {'Std Dev':<15}")
            print(f"   {'─'*60}")
            print(f"   {'Accuracy':<15} {m['accuracy']:>10.2f}%     ± {m['accuracy_std']:>6.2f}%")
            print(f"   {'Sensitivity':<15} {m['sensitivity']:>10.2f}%     ± {m['sensitivity_std']:>6.2f}%")
            print(f"   {'Specificity':<15} {m['specificity']:>10.2f}%     ± {m['specificity_std']:>6.2f}%")
            print(f"   {'Precision':<15} {m['precision']:>10.2f}%     ± {m['precision_std']:>6.2f}%")
            print(f"   {'F1-Score':<15} {m['f1_score']:>10.2f}%     ± {m['f1_score_std']:>6.2f}%")
            print(f"   {'AUC':<15} {m['auc']:>10.2f}%     ± {m['auc_std']:>6.2f}%")
            print(f"   {'─'*60}")
            
            # Formato para tabla científica
            print(f"\n📋 FORMAT FOR SCIENTIFIC TABLES:")
            print(f"   ┌─────────────┬────────────────────────┐")
            print(f"   │ Metric      │ Value (mean ± std)     │")
            print(f"   ├─────────────┼────────────────────────┤")
            print(f"   │ Accuracy    │ {m['accuracy']/100:.2f} ± {m['accuracy_std']/100:.2f}          │")
            print(f"   │ Sensitivity │ {m['sensitivity']/100:.2f} ± {m['sensitivity_std']/100:.2f}          │")
            print(f"   │ Specificity │ {m['specificity']/100:.2f} ± {m['specificity_std']/100:.2f}          │")
            print(f"   │ Precision   │ {m['precision']/100:.2f} ± {m['precision_std']/100:.2f}          │")
            print(f"   │ F1-Score    │ {m['f1_score']/100:.2f} ± {m['f1_score_std']/100:.2f}          │")
            print(f"   │ AUC         │ {m['auc']/100:.2f} ± {m['auc_std']/100:.2f}          │")
            print(f"   └─────────────┴────────────────────────┘")
            
            # Formato LaTeX
            arch = self._format_architecture(best)
            print(f"\n📄 LaTeX FORMAT:")
            latex = f"   Neuroevolution-{arch} & {m['accuracy']/100:.2f} (±{m['accuracy_std']/100:.2f}) & {m['sensitivity']/100:.2f} (±{m['sensitivity_std']/100:.2f}) & {m['specificity']/100:.2f} (±{m['specificity_std']/100:.2f}) & {m['f1_score']/100:.2f} (±{m['f1_score_std']/100:.2f}) & {m['auc']/100:.2f} (±{m['auc_std']/100:.2f}) \\\\\\\\"
            print(latex)
            
            # Formato Markdown
            print(f"\n📝 Markdown FORMAT:")
            markdown = f"   | Neuroevolution-{arch} | {m['accuracy']/100:.2f} (±{m['accuracy_std']/100:.2f}) | {m['sensitivity']/100:.2f} (±{m['sensitivity_std']/100:.2f}) | {m['specificity']/100:.2f} (±{m['specificity_std']/100:.2f}) | {m['f1_score']/100:.2f} (±{m['f1_score_std']/100:.2f}) | {m['auc']/100:.2f} (±{m['auc_std']/100:.2f}) |"
            print(markdown)
            
            # Mostrar métricas por fold si están disponibles
            if m.get('fold_metrics'):
                print(f"\n📈 METRICS BY FOLD:")
                print(f"   {'Fold':<6} {'Acc':<10} {'Sen':<10} {'Spe':<10} {'Pre':<10} {'F1':<10} {'AUC':<10}")
                print(f"   {'-'*66}")
                for fold_num, fold_m in sorted(m['fold_metrics'].items()):
                    if fold_m:
                        print(f"   {fold_num:<6} {fold_m['accuracy']:>6.2f}%   {fold_m['sensitivity']:>6.2f}%   "
                              f"{fold_m['specificity']:>6.2f}%   {fold_m['precision']:>6.2f}%   "
                              f"{fold_m['f1_score']:>6.2f}%   {fold_m['auc']:>6.2f}%")
                print(f"   {'-'*66}")
        else:
            print(f"\n⚠️ No detailed metrics available for best individual")
        
        print(f"\n{'#'*100}")

    def evolve(self) -> dict:
        """Main evolution loop."""
        print("STARTING HYBRID NEUROEVOLUTION PROCESS (adaptive mutation + generation-level early stopping)")
        print("="*80)
        print(f"Configuration:")
        print(f"   Population: {self.config['population_size']} individuals")
        print(f"   Maximum generations: {self.config['max_generations']}")
        print(f"   Target fitness: {self.config['fitness_threshold']}%")
        print(f"   Early stopping (generations): {self.config['early_stopping_generations']} without improvement")
        print(f"   Min improvement threshold: {self.config['min_improvement_threshold']}%")
        print(
            "   Residual search: "
            f"enabled_weight={self.config.get('residual_enabled_weight', 0.35)}, "
            f"disabled_weight={self.config.get('residual_disabled_weight', 0.65)}, "
            f"block_sizes={self.config.get('residual_block_size_options', [2, 3])}"
        )
        print(f"   Device: {self.device}")
        print("="*80)
        
        self.initialize_population()
        
        while not self.check_convergence():
            print(f"\n{'='*80}")
            print(f"GENERATION {self.generation}")
            print(f"{'='*80}")
            
            self.evaluate_population()
            self._save_evolution_progress()
            
            if self.check_convergence():
                break
            
            self._update_adaptive_mutation()
            self.generation += 1
            self._update_incremental_complexity()
            self.selection_and_reproduction()
            self._save_evolution_progress()
            print(f"\nPreparing for next generation...")
        
        print(f"\n{'='*80}")
        print(f"EVOLUTION COMPLETED!")
        print(f"{'='*80}")
        print(f"Best individual found:")
        print(f"   ID: {self.best_individual['id']}")
        print(f"   Fitness: {self.best_individual['fitness']:.2f}%")
        print(f"   Origin generation: {self.generation}")
        print(f"   Total generations processed: {self.generation + 1}")
        print(f"   Generations without improvement: {self.generations_without_improvement}/{self.max_generations_without_improvement}")
        
        self._print_final_metrics_summary()
        
        print("="*80)
        return self.best_individual
