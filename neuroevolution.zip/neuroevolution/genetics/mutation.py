"""
Mutation operators for genome evolution.
"""

import random
import copy
import uuid
from neuroevolution.config import ACTIVATION_FUNCTIONS, OPTIMIZERS, optimizer_learning_rates
from neuroevolution.genetics.genome import invalidate_evaluation
from neuroevolution.genetics.architecture_templates import apply_template_module_to_genome
from neuroevolution.models.genome_validator import (
    architecture_spatial_limit,
    calculate_max_safe_conv_layers,
    is_genome_valid,
    validate_and_fix_genome,
)
from neuroevolution.genetics.innovation import build_innovation_genes, append_structural_event


def _generation_delta(config: dict) -> tuple:
    """Returns a layer-count mutation delta that grows with the current generation."""
    generation_number = max(1, int(config.get('current_generation', 1)))
    generation_factor = float(config.get('structural_mutation_generation_factor', 0.5))
    max_delta = max(1, int(generation_number * generation_factor))
    return random.randint(1, max_delta), generation_number, max_delta


def _bounded_layer_target(current_value: int, delta: int, minimum: int, maximum: int) -> tuple:
    """Chooses +/- delta and clamps the result inside the configured layer bounds."""
    direction = random.choice([-1, 1])

    for candidate_direction in (direction, -direction):
        raw_target = current_value + (candidate_direction * delta)
        target = max(minimum, min(maximum, raw_target))
        if target != current_value:
            return target, candidate_direction

    return current_value, 0


def _mutate_layer_count(mutated_genome: dict, config: dict, safe_max_conv: int, fc_cap: int) -> None:
    """Mutates either Conv1D or FC depth by a generation-scaled random delta."""
    delta, generation_number, max_delta = _generation_delta(config)

    layer_kinds = ['conv', 'fc']
    random.shuffle(layer_kinds)

    for layer_kind in layer_kinds:
        if layer_kind == 'conv':
            key = 'num_conv_layers'
            minimum = int(config['min_conv_layers'])
            maximum = int(safe_max_conv)
            event_type = 'mutate_conv_layer_count'
        else:
            key = 'num_fc_layers'
            minimum = int(config['min_fc_layers'])
            maximum = int(fc_cap)
            event_type = 'mutate_fc_layer_count'

        current_value = int(mutated_genome[key])
        target, direction = _bounded_layer_target(current_value, delta, minimum, maximum)
        if target == current_value:
            continue

        mutated_genome[key] = target
        append_structural_event(
            mutated_genome,
            event_type,
            {
                'old': current_value,
                'new': target,
                'requested_delta': int(delta),
                'direction': '+' if direction > 0 else '-',
                'current_generation': int(generation_number),
                'max_delta_for_generation': int(max_delta),
                'min_layers': int(minimum),
                'max_layers': int(maximum)
            }
        )
        return


def _mutate_residual_topology(mutated_genome: dict, config: dict) -> None:
    """Mutates residual topology fields and records the structural event."""
    validate_and_fix_genome(mutated_genome, config)

    block_options = list(config.get('residual_block_size_options', [2]))
    projection_options = list(config.get('residual_projection_options', ['auto']))
    candidates = ['enabled']

    if len(block_options) > 1:
        candidates.append('block_size')
    if len(projection_options) > 1:
        candidates.append('projection')

    mutation_kind = random.choice(candidates)

    if mutation_kind == 'enabled':
        old_value = bool(mutated_genome.get('residual_enabled', False))
        new_value = not old_value
        mutated_genome['residual_enabled'] = new_value
        mutated_genome['inception_enabled'] = False
        mutated_genome['conv_topology'] = 'residual' if new_value else 'sequential'
        validate_and_fix_genome(mutated_genome, config)
        append_structural_event(
            mutated_genome,
            'mutate_residual_enabled',
            {'old': old_value, 'new': bool(mutated_genome['residual_enabled'])}
        )
        return

    if mutation_kind == 'block_size':
        old_value = int(mutated_genome.get('residual_block_size', block_options[0]))
        available = [option for option in block_options if int(option) != old_value]
        new_value = int(random.choice(available))
        mutated_genome['residual_block_size'] = new_value
        validate_and_fix_genome(mutated_genome, config)
        append_structural_event(
            mutated_genome,
            'mutate_residual_block_size',
            {'old': old_value, 'new': int(mutated_genome['residual_block_size'])}
        )
        return

    old_value = str(mutated_genome.get('residual_projection', projection_options[0]))
    available = [option for option in projection_options if str(option) != old_value]
    new_value = str(random.choice(available))
    mutated_genome['residual_projection'] = new_value
    validate_and_fix_genome(mutated_genome, config)
    append_structural_event(
        mutated_genome,
        'mutate_residual_projection',
        {'old': old_value, 'new': str(mutated_genome['residual_projection'])}
    )


def _mutate_inception_topology(mutated_genome: dict, config: dict) -> None:
    """Mutates Inception topology fields and records the structural event."""
    validate_and_fix_genome(mutated_genome, config)

    reduction_options = list(config.get('inception_reduction_ratio_options', [0.5]))
    pool_options = list(config.get('inception_pool_branch_options', [True]))
    candidates = ['enabled']

    if mutated_genome.get('inception_enabled', False):
        if len(reduction_options) > 1:
            candidates.append('reduction_ratio')
        if len(pool_options) > 1:
            candidates.append('pool_branch')

    mutation_kind = random.choice(candidates)

    if mutation_kind == 'enabled':
        old_value = bool(mutated_genome.get('inception_enabled', False))
        new_value = not old_value
        mutated_genome['inception_enabled'] = new_value
        mutated_genome['residual_enabled'] = False
        mutated_genome['conv_topology'] = 'inception' if new_value else 'sequential'
        validate_and_fix_genome(mutated_genome, config)
        append_structural_event(
            mutated_genome,
            'mutate_inception_enabled',
            {'old': old_value, 'new': bool(mutated_genome['inception_enabled'])}
        )
        return

    if mutation_kind == 'reduction_ratio':
        old_value = float(mutated_genome.get('inception_reduction_ratio', reduction_options[0]))
        available = [float(option) for option in reduction_options if float(option) != old_value]
        new_value = float(random.choice(available))
        mutated_genome['inception_reduction_ratio'] = new_value
        mutated_genome['conv_topology'] = 'inception'
        validate_and_fix_genome(mutated_genome, config)
        append_structural_event(
            mutated_genome,
            'mutate_inception_reduction_ratio',
            {'old': old_value, 'new': float(mutated_genome['inception_reduction_ratio'])}
        )
        return

    old_value = bool(mutated_genome.get('inception_pool_branch', pool_options[0]))
    available = [bool(option) for option in pool_options if bool(option) != old_value]
    new_value = bool(random.choice(available))
    mutated_genome['inception_pool_branch'] = new_value
    mutated_genome['conv_topology'] = 'inception'
    validate_and_fix_genome(mutated_genome, config)
    append_structural_event(
        mutated_genome,
        'mutate_inception_pool_branch',
        {'old': old_value, 'new': bool(mutated_genome['inception_pool_branch'])}
    )


def mutate_genome(genome: dict, config: dict) -> dict:
    """
    Applies mutation to a genome using adaptive mutation rate and configurable parameters.
    Includes incremental structural growth and innovation UUID tracking.
    
    Args:
        genome: Original genome to mutate
        config: Configuration dictionary
    
    Returns:
        Mutated genome (new copy)
    """
    if genome.get('model_kind') == 'reference':
        mutated = invalidate_evaluation(copy.deepcopy(genome))
        if random.random() < config['architecture_template_mutation_weight']:
            mutated = apply_template_module_to_genome(mutated, config)
        if random.random() < config['current_mutation_rate']:
            mutated['optimizer'] = random.choice(config['optimizer_options'])
        if random.random() < config['current_mutation_rate'] or mutated['learning_rate'] not in optimizer_learning_rates(config, mutated['optimizer']):
            mutated['learning_rate'] = random.choice(optimizer_learning_rates(config, mutated['optimizer']))
        mutated['id'] = str(uuid.uuid4())[:8]
        mutated['innovation_genes'] = build_innovation_genes(mutated)
        append_structural_event(mutated, 'reference_training_mutation', {'optimizer': mutated['optimizer'], 'learning_rate': mutated['learning_rate']})
        return validate_and_fix_genome(mutated, config)
    max_attempts = int(config.get('mutation_max_attempts', 50))

    for attempt in range(max_attempts):
        mutated_genome = invalidate_evaluation(copy.deepcopy(genome))

        mutation_rate = config['current_mutation_rate']

        # Structural mutation uses global config bounds. Incremental caps are only
        # for initial seeding, otherwise selected deep parents collapse to shallow
        # children during early generations.
        conv_cap = int(config['max_conv_layers'])
        fc_cap = int(config['max_fc_layers'])

        mutated_genome = validate_and_fix_genome(mutated_genome, config)

        # Also enforce architecture safety with sequence length. Residual mode
        # pools per block, so it has its own safe depth.
        sequence_length = architecture_spatial_limit(config)
        min_required_length = 4
        max_safe_conv_layers = calculate_max_safe_conv_layers(
            sequence_length,
            min_required_length=min_required_length,
            residual_enabled=mutated_genome.get('residual_enabled', False),
            residual_block_size=mutated_genome.get('residual_block_size', 2),
        )
        safe_max_conv = max(config['min_conv_layers'], min(conv_cap, max_safe_conv_layers))
        fc_cap = max(config['min_fc_layers'], fc_cap)

        # Structural mutation: jump +/- a generation-scaled amount, then clamp to safe config bounds.
        if random.random() < mutation_rate:
            _mutate_layer_count(mutated_genome, config, safe_max_conv, fc_cap)

        # Validate and fix lists to match layer counts
        mutated_genome = validate_and_fix_genome(mutated_genome, config)

        if random.random() < config.get('residual_mutation_weight', 0.15):
            _mutate_residual_topology(mutated_genome, config)

        if random.random() < config.get('inception_mutation_weight', 0.15):
            _mutate_inception_topology(mutated_genome, config)

        if random.random() < config.get('architecture_template_mutation_weight', 0.0):
            try:
                mutated_genome = apply_template_module_to_genome(mutated_genome, config)
                if mutated_genome.get('model_kind') == 'reference':
                    return mutated_genome
            except ValueError:
                continue

        # Mutate filters
        for i in range(len(mutated_genome['filters'])):
            if random.random() < mutation_rate:
                old_val = mutated_genome['filters'][i]
                new_val = random.randint(config['min_filters'], config['max_filters'])
                mutated_genome['filters'][i] = new_val
                append_structural_event(mutated_genome, 'mutate_conv_filter', {'index': i, 'old': int(old_val), 'new': int(new_val)})

        # Mutate kernel sizes
        for i in range(len(mutated_genome['kernel_sizes'])):
            if random.random() < mutation_rate:
                old_val = mutated_genome['kernel_sizes'][i]
                new_val = random.choice(config['kernel_size_options'])
                mutated_genome['kernel_sizes'][i] = new_val
                append_structural_event(mutated_genome, 'mutate_conv_kernel', {'index': i, 'old': int(old_val), 'new': int(new_val)})

        # Mutate FC nodes
        for i in range(len(mutated_genome['fc_nodes'])):
            if random.random() < mutation_rate:
                old_val = mutated_genome['fc_nodes'][i]
                new_val = random.randint(config['min_fc_nodes'], config['max_fc_nodes'])
                mutated_genome['fc_nodes'][i] = new_val
                append_structural_event(mutated_genome, 'mutate_fc_node', {'index': i, 'old': int(old_val), 'new': int(new_val)})

        # Mutate activation functions
        for i in range(len(mutated_genome['activations'])):
            if random.random() < mutation_rate:
                mutated_genome['activations'][i] = random.choice(config.get('activation_options', list(ACTIVATION_FUNCTIONS)))

        # Mutate dropout
        if random.random() < mutation_rate:
            mutated_genome['dropout_rate'] = random.uniform(config['min_dropout'], config['max_dropout'])

        # Mutate learning rate
        # Optimizer and its learning rate are coupled, rather than using an
        # Adam-sized range for SGD without momentum.
        if random.random() < mutation_rate:
            mutated_genome['optimizer'] = random.choice(config.get('optimizer_options', list(OPTIMIZERS)))
        rates = optimizer_learning_rates(config, mutated_genome['optimizer'])
        if random.random() < mutation_rate or mutated_genome['learning_rate'] not in rates:
            mutated_genome['learning_rate'] = random.choice(rates)

        # Mutate normalization type
        if random.random() < mutation_rate:
            mutated_genome['normalization_type'] = random.choices(
                ['batch', 'layer'],
                weights=[config['normalization_batch_weight'], config['normalization_layer_weight']]
            )[0]

        mutated_genome['id'] = str(uuid.uuid4())[:8]
        mutated_genome['fitness'] = 0.0

        # Final validation
        mutated_genome = validate_and_fix_genome(mutated_genome, config)

        if is_genome_valid(mutated_genome, config):
            mutated_genome['innovation_genes'] = build_innovation_genes(mutated_genome)
            return mutated_genome

    print(f"⚠️ Warning: Could not create valid mutation after {max_attempts} attempts. Using safe fallback.")
    safe_genome = invalidate_evaluation(copy.deepcopy(genome))

    safe_genome = validate_and_fix_genome(safe_genome, config)
    safe_max_conv = calculate_max_safe_conv_layers(
        architecture_spatial_limit(config),
        min_required_length=4,
        residual_enabled=safe_genome.get('residual_enabled', False),
        residual_block_size=safe_genome.get('residual_block_size', 2),
    )
    safe_max_conv = max(config['min_conv_layers'], min(config['max_conv_layers'], safe_max_conv))

    safe_genome['num_conv_layers'] = max(
        config['min_conv_layers'],
        min(safe_genome['num_conv_layers'], safe_max_conv)
    )
    safe_genome['num_fc_layers'] = max(
        config['min_fc_layers'],
        min(safe_genome['num_fc_layers'], fc_cap)
    )
    safe_genome = validate_and_fix_genome(safe_genome, config)
    safe_genome['id'] = str(uuid.uuid4())[:8]
    safe_genome['fitness'] = 0.0
    safe_genome['innovation_genes'] = build_innovation_genes(safe_genome)

    return safe_genome
