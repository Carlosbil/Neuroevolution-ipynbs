"""
Genome creation functions for neuroevolution.
"""

import random
import uuid
from neuroevolution.config import ACTIVATION_FUNCTIONS, OPTIMIZERS, optimizer_learning_rates, config_value
from neuroevolution.models.genome_validator import (
    architecture_spatial_limit,
    calculate_max_safe_conv_layers,
    is_genome_valid,
    validate_and_fix_genome,
)
from neuroevolution.genetics.innovation import build_innovation_genes


def invalidate_evaluation(genome: dict) -> dict:
    """A child never inherits its parent's evaluation or cost measurements."""
    for key in ('metrics', 'evaluation_status', 'evaluation_time_seconds', 'parameter_count',
                'pareto_rank', 'crowding_distance', 'selection_objectives',
                'skip_next_evaluation', 'cached_from_generation', 'species_id', 'adjusted_fitness'):
        genome.pop(key, None)
    genome['fitness'] = 0.0
    return genome


def _sample_conv_topology(config: dict) -> str:
    """Samples the active Conv1D topology, preferring the new topology weights."""
    topology_weights = config.get('conv_topology_weights')
    if topology_weights:
        topologies = ['sequential', 'residual', 'inception']
        weights = [float(topology_weights.get(topology, 0.0)) for topology in topologies]
        if sum(weights) > 0:
            return random.choices(topologies, weights=weights)[0]

    residual_enabled = random.choices(
        [True, False],
        weights=[
            config.get('residual_enabled_weight', 0.35),
            config.get('residual_disabled_weight', 0.65),
        ],
    )[0]
    return 'residual' if residual_enabled else 'sequential'


def create_random_genome(config: dict) -> dict:
    """
    Creates a random genome within specified ranges (optimized for 1D audio).
    Ensures the genome will produce a valid architecture.
    
    Args:
        config: Configuration dictionary
    
    Returns:
        Valid genome dictionary
    """
    max_attempts = int(config_value(config, 'random_genome_max_attempts'))
    attempt = 0

    # Incremental caps (if not present, use full limits)
    conv_cap = config.get('current_max_conv_layers', config['max_conv_layers'])
    fc_cap = config.get('current_max_fc_layers', config['max_fc_layers'])

    while attempt < max_attempts:
        conv_topology = _sample_conv_topology(config)
        residual_block_options = config.get('residual_block_size_options', [2])
        residual_projection_options = config.get('residual_projection_options', ['auto'])
        inception_reduction_options = config.get('inception_reduction_ratio_options', [0.5])
        inception_pool_options = config.get('inception_pool_branch_options', [True])
        residual_enabled = conv_topology == 'residual'
        inception_enabled = conv_topology == 'inception'
        residual_block_size = random.choice(residual_block_options)
        residual_projection = random.choice(residual_projection_options)
        inception_reduction_ratio = random.choice(inception_reduction_options)
        inception_pool_branch = random.choice(inception_pool_options)

        # Calculate maximum safe conv layers based on sequence length and
        # selected topology. Residual mode pools per block, so deeper stacks can
        # still be safe.
        sequence_length = architecture_spatial_limit(config)
        min_required_length = config_value(config, 'minimum_feature_map_size')
        max_safe_conv_layers = calculate_max_safe_conv_layers(
            sequence_length,
            min_required_length=min_required_length,
            residual_enabled=residual_enabled,
            residual_block_size=residual_block_size,
        )

        # Limit conv layers to safe maximum
        safe_max_conv = min(conv_cap, max_safe_conv_layers)
        safe_max_conv = max(config['min_conv_layers'], safe_max_conv)

        # Number of layers
        num_conv_layers = random.randint(config['min_conv_layers'], safe_max_conv)
        num_fc_layers = random.randint(config['min_fc_layers'], fc_cap)

        # Filters for each convolutional layer (progressive increase)
        filters = []
        base_filters = random.randint(config['min_filters'], config['min_filters'] * 2)
        for i in range(num_conv_layers):
            layer_filters = min(base_filters * (2 ** i), config['max_filters'])
            filters.append(layer_filters)

        # Kernel sizes (using configured options)
        kernel_sizes = [random.choice(config['kernel_size_options']) for _ in range(num_conv_layers)]

        # Nodes in fully connected layers (progressive decrease)
        fc_nodes = []
        base_fc = random.randint(config['min_fc_nodes'], config['max_fc_nodes'])
        for i in range(num_fc_layers):
            layer_nodes = max(config['min_fc_nodes'], base_fc // (2 ** i))
            fc_nodes.append(layer_nodes)

        # Activation functions for each layer
        activations = [random.choice(config.get('activation_options', list(ACTIVATION_FUNCTIONS))) for _ in range(max(num_conv_layers, num_fc_layers))]

        # Other parameters (using configured ranges and options)
        dropout_rate = random.uniform(config['min_dropout'], config['max_dropout'])
        optimizer = random.choice(config.get('optimizer_options', list(OPTIMIZERS)))
        learning_rate = random.choice(optimizer_learning_rates(config, optimizer))
        normalization_type = random.choices(['batch', 'layer'], weights=[
            config_value(config, 'normalization_batch_weight'),
            config_value(config, 'normalization_layer_weight'),
        ])[0]

        genome = {
            'num_conv_layers': num_conv_layers,
            'num_fc_layers': num_fc_layers,
            'filters': filters,
            'kernel_sizes': kernel_sizes,
            'fc_nodes': fc_nodes,
            'activations': activations,
            'dropout_rate': dropout_rate,
            'learning_rate': learning_rate,
            'optimizer': optimizer,
            'normalization_type': normalization_type,
            'conv_topology': conv_topology,
            'residual_enabled': residual_enabled,
            'residual_block_size': residual_block_size,
            'residual_projection': residual_projection,
            'inception_enabled': inception_enabled,
            'inception_reduction_ratio': inception_reduction_ratio,
            'inception_pool_branch': inception_pool_branch,
            'fitness': 0.0,
            'id': str(uuid.uuid4())[:8],
            'structural_history': []
        }

        genome = validate_and_fix_genome(genome, config)
        if is_genome_valid(genome, config):
            genome['innovation_genes'] = build_innovation_genes(genome)
            return genome

        attempt += 1

    print(f"⚠️ Warning: Could not create random genome after {max_attempts} attempts. Creating minimal safe genome.")
    genome = {
        'num_conv_layers': config['min_conv_layers'],
        'num_fc_layers': config['min_fc_layers'],
        'filters': [config['min_filters']] * config['min_conv_layers'],
        'kernel_sizes': [min(config['kernel_size_options'])] * config['min_conv_layers'],
        'fc_nodes': [config['min_fc_nodes']] * config['min_fc_layers'],
        'activations': [config_value(config, 'activation_options')[0]] * max(config['min_conv_layers'], config['min_fc_layers']),
        'dropout_rate': config['min_dropout'],
        'learning_rate': optimizer_learning_rates(config, config_value(config, 'optimizer_options')[0])[0],
        'optimizer': config_value(config, 'optimizer_options')[0],
        'normalization_type': 'batch',
        'conv_topology': 'sequential',
        'residual_enabled': False,
        'residual_block_size': 2,
        'residual_projection': 'auto',
        'inception_enabled': False,
        'inception_reduction_ratio': 0.5,
        'inception_pool_branch': True,
        'fitness': 0.0,
        'id': str(uuid.uuid4())[:8],
        'structural_history': []
    }
    genome = validate_and_fix_genome(genome, config)
    if not is_genome_valid(genome, config):
        raise ValueError('Configured search bounds cannot produce a valid random genome')
    genome['innovation_genes'] = build_innovation_genes(genome)
    return genome
