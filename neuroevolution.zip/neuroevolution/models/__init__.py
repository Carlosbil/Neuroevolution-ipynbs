"""
Neural network models package.
"""
