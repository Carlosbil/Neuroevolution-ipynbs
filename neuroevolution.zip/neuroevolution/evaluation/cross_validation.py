"""
Final 5-fold train/validation/test evaluation utilities for the best genome.

This module extracts notebook evaluation logic so notebooks orchestrate calls
without embedding training/evaluation implementations inline.
"""

from __future__ import annotations

import json
import os
from datetime import datetime
from typing import Any, Dict, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.metrics import confusion_matrix

from ..config import OPTIMIZERS, get_data_phase_config
from ..evolution.fitness import (
    FoldLoaders,
    compute_classification_metrics,
    load_fold_data as load_fold_data_from_evolution,
    load_fold_loaders as load_fold_loaders_from_evolution,
    metric_value,
    resolve_metric_improvement_threshold,
    resolve_metric_name,
)
from ..models.architecture_formatting import format_genome_architecture
from ..models.evolvable_cnn import EvolvableCNN


def _format_architecture(genome: dict) -> str:
    return format_genome_architecture(genome)


def _to_json_compatible(value: Any) -> Any:
    """Recursively convert NumPy and tensor values to JSON-native types."""
    if isinstance(value, dict):
        return {str(key): _to_json_compatible(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_to_json_compatible(item) for item in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, torch.Tensor):
        return value.detach().cpu().tolist()
    return value


def load_fold_loaders(
    config: dict,
    fold_number: int,
    device: Optional[torch.device] = None
) -> FoldLoaders:
    """
    Load train/validation/test dataloaders for a specific fold.

    Args:
        config: System configuration dictionary.
        fold_number: Fold number (1-5).
        device: PyTorch device. If not provided, auto-detected.

    Returns:
        FoldLoaders with train, validation, and test loaders.
    """
    if device is None:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    return load_fold_loaders_from_evolution(fold_number, config, device)


def load_fold_data(
    config: dict,
    fold_number: int,
    device: Optional[torch.device] = None
) -> Tuple[
    torch.utils.data.DataLoader,
    torch.utils.data.DataLoader,
    torch.utils.data.DataLoader,
]:
    """
    Load train, validation, and test dataloaders for a specific fold.

    Args:
        config: System configuration dictionary.
        fold_number: Fold number (1-5).
        device: PyTorch device. If not provided, auto-detected.

    Returns:
        Tuple of (fold_train_loader, fold_validation_loader, fold_test_loader).
    """
    if device is None:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    return load_fold_data_from_evolution(fold_number, config, device, eval_split="all")


def _evaluate_loader_metrics(
    model: nn.Module,
    loader: torch.utils.data.DataLoader,
    device: torch.device,
) -> Dict[str, Any]:
    """Evaluate one explicit loader and retain the data needed for reporting."""
    model.eval()
    predictions = []
    targets = []
    probabilities = []

    with torch.no_grad():
        for data, target in loader:
            data = data.to(device, non_blocking=True)
            target = target.to(device, non_blocking=True)
            output = model(data)
            probs = F.softmax(output, dim=1)
            predicted = torch.argmax(output, dim=1)

            predictions.extend(predicted.cpu().tolist())
            targets.extend(target.cpu().tolist())
            probabilities.extend(probs[:, 1].float().cpu().tolist())

    metrics = compute_classification_metrics(targets, predictions, probabilities)
    metrics['confusion_matrix'] = confusion_matrix(targets, predictions)
    metrics['n_samples'] = len(targets)
    return metrics


def _evaluate_single_fold_legacy(
    best_genome: dict,
    config: dict,
    fold_train_loader: torch.utils.data.DataLoader,
    fold_validation_loader: torch.utils.data.DataLoader,
    fold_test_loader: torch.utils.data.DataLoader,
    fold_num: int,
    device: torch.device,
    num_epochs: int = 100,
    use_pretrained: bool = False,
    pretrained_model: Optional[nn.Module] = None
) -> Dict[str, Any]:
    """
    Deprecated implementation retained for historical checkpoint compatibility.

    The public implementation below is the only evaluation path used by the
    package and notebook.

    Args:
        best_genome: Best architecture genome.
        config: System configuration dictionary.
        fold_train_loader: Fold training dataloader.
        fold_validation_loader: Fold validation dataloader for epoch selection.
        fold_test_loader: Fold test dataloader for final reported metrics.
        fold_num: Fold number (1-5).
        device: Device to train/evaluate on.
        num_epochs: Max epochs for this fold.
        use_pretrained: Whether to initialize from pretrained checkpoint.
        pretrained_model: Optional pretrained model instance.

    Returns:
        Dictionary with fold metrics and metadata.
    """
    print(f"\n{'='*70}")
    print(f"FOLD {fold_num}/5")
    print(f"{'='*70}")

    model = EvolvableCNN(best_genome, config).to(device)

    if use_pretrained and pretrained_model is not None:
        print("   Inicializando desde modelo pre-entrenado...")
        try:
            model.load_state_dict(pretrained_model.state_dict())
            print("   ✓ Pesos pre-entrenados cargados exitosamente")
        except Exception as e:
            print(f"   ✗ Error cargando pesos pre-entrenados: {e}")
            print("   Continuando con pesos aleatorios...")

    optimizer_class = OPTIMIZERS[best_genome["optimizer"]]
    optimizer = optimizer_class(model.parameters(), lr=best_genome["learning_rate"])
    criterion = nn.CrossEntropyLoss()

    selection_metric = resolve_metric_name(config, "fold_selection_metric")
    best_selection_score = float("-inf")
    best_selection_metrics = None
    best_model_state = None
    best_epoch = 0

    patience = config.get("epoch_patience", 10)
    patience_counter = 0
    last_improvement_score = float("-inf")
    improvement_threshold = resolve_metric_improvement_threshold(config)

    print(f"Entrenando por hasta {num_epochs} épocas (patience={patience})...")
    print(f"Guardando el MEJOR modelo basado en {selection_metric} de validación")

    for epoch in range(1, num_epochs + 1):
        model.train()
        running_loss = 0.0
        batch_count = 0

        for data, target in fold_train_loader:
            data, target = data.to(device, non_blocking=True), target.to(device, non_blocking=True)

            optimizer.zero_grad()
            output = model(data)
            loss = criterion(output, target)
            loss.backward()
            optimizer.step()

            running_loss += loss.item()
            batch_count += 1

        avg_loss = running_loss / max(1, batch_count)

        model.eval()
        validation_predictions = []
        validation_targets = []
        validation_probs = []

        with torch.no_grad():
            for data, target in fold_validation_loader:
                data, target = data.to(device, non_blocking=True), target.to(device, non_blocking=True)
                output = model(data)
                probs = F.softmax(output, dim=1)
                _, predicted = torch.max(output, 1)

                validation_predictions.extend(predicted.cpu().numpy())
                validation_targets.extend(target.cpu().numpy())
                validation_probs.extend(probs[:, 1].cpu().numpy())

        validation_metrics = compute_classification_metrics(
            validation_targets,
            validation_predictions,
            validation_probs,
        )
        current_selection_score = metric_value(validation_metrics, selection_metric)

        if current_selection_score > (best_selection_score + improvement_threshold):
            best_selection_score = current_selection_score
            best_selection_metrics = validation_metrics
            best_model_state = {k: v.clone() for k, v in model.state_dict().items()}
            best_epoch = epoch
            print(
                f"   Época {epoch}/{num_epochs}: loss={avg_loss:.4f}, "
                f"val_{selection_metric}={current_selection_score:.2f}% *** NUEVO MEJOR ***"
            )

        improvement = current_selection_score - last_improvement_score
        if improvement >= improvement_threshold:
            patience_counter = 0
            last_improvement_score = current_selection_score
        else:
            patience_counter += 1

        if epoch % 30 == 0 or epoch == 1:
            print(
                f"   Época {epoch}/{num_epochs}: loss={avg_loss:.4f}, "
                f"val_{selection_metric}={current_selection_score:.2f}% "
                f"(best={best_selection_score:.2f}%)"
            )

        if patience_counter >= patience:
            print(f"   Early stopping en época {epoch} (sin mejora por {patience} épocas)")
            break

    if best_model_state is not None:
        model.load_state_dict(best_model_state)
        print(
            f"\n   ✓ Cargado mejor modelo de época {best_epoch} "
            f"(val_{selection_metric}={best_selection_score:.2f}%)"
        )
    else:
        print("\n   ⚠ Usando modelo final (no se encontró mejora)")

    print("Evaluando test con el mejor modelo seleccionado por validación...")
    model.eval()
    all_predictions = []
    all_targets = []
    all_probs = []

    with torch.no_grad():
        for data, target in loader:
            data, target = data.to(device, non_blocking=True), target.to(device, non_blocking=True)
            output = model(data)

            probs = F.softmax(output, dim=1)
            _, predicted = torch.max(output, 1)

            all_predictions.extend(predicted.cpu().numpy())
            all_targets.extend(target.cpu().numpy())
            all_probs.extend(probs.cpu().numpy())

    y_true = np.array(all_targets)
    y_pred = np.array(all_predictions)
    y_probs = np.array(all_probs)

    test_metrics = compute_classification_metrics(y_true, y_pred, y_probs)
    cm = confusion_matrix(y_true, y_pred)
    if best_selection_metrics is None:
        best_selection_metrics = test_metrics
        best_selection_score = metric_value(best_selection_metrics, selection_metric)
    best_validation_acc = metric_value(best_selection_metrics, "accuracy")

    print(f"\nResultados Test Fold {fold_num} (mejor época por validación: {best_epoch}):")
    print(f"   Accuracy:     {test_metrics['accuracy']:.2f}%")
    print(f"   Sensitivity:  {test_metrics['sensitivity']:.2f}%")
    print(f"   Specificity:  {test_metrics['specificity']:.2f}%")
    print(f"   F1-Score:     {test_metrics['f1_score']:.2f}%")
    print(f"   AUC:          {test_metrics['auc']:.2f}%")

    return {
        "fold": fold_num,
        "accuracy": test_metrics["accuracy"],
        "sensitivity": test_metrics["sensitivity"],
        "specificity": test_metrics["specificity"],
        "f1_score": test_metrics["f1_score"],
        "auc": test_metrics["auc"],
        "confusion_matrix": cm,
        "n_samples": len(y_true),
    }


def evaluate_single_fold(
    best_genome: dict,
    config: dict,
    fold_train_loader: torch.utils.data.DataLoader,
    fold_validation_loader: torch.utils.data.DataLoader,
    fold_test_loader: torch.utils.data.DataLoader,
    fold_num: int,
    device: torch.device,
    num_epochs: int = 100
) -> Dict[str, Any]:
    """
    Train one fold with validation selection and evaluate once on held-out test.

    Args:
        best_genome: Best architecture genome.
        config: System configuration dictionary.
        fold_train_loader: Fold training dataloader.
        fold_validation_loader: Fold validation dataloader used for selection.
        fold_test_loader: Fold held-out test dataloader used for final metrics.
        fold_num: Fold number (1-5).
        device: Device to train/evaluate on.
        num_epochs: Max epochs for this fold.

    Returns:
        Dictionary with fold metrics and metadata.
    """
    print(f"\n{'='*70}")
    print(f"FOLD {fold_num}/5")
    print(f"{'='*70}")

    model = EvolvableCNN(best_genome, config).to(device)

    optimizer_class = OPTIMIZERS[best_genome["optimizer"]]
    optimizer = optimizer_class(model.parameters(), lr=best_genome["learning_rate"])
    criterion = nn.CrossEntropyLoss()

    selection_metric = resolve_metric_name(config, "fold_selection_metric")
    checkpoint_metric = config.get("checkpoint_metric", config.get("fitness_metric", "f1_score"))
    best_selection_score = -float("inf")
    best_selection_metrics = None
    best_model_state = None
    best_epoch = 0

    patience = config.get("epoch_patience", 10)
    patience_counter = 0
    last_improvement_score = -float("inf")
    improvement_threshold = resolve_metric_improvement_threshold(config)

    print(f"Entrenando por hasta {num_epochs} épocas (patience={patience})...")
    print(f"Guardando el MEJOR modelo basado en validation {selection_metric}")

    for epoch in range(1, num_epochs + 1):
        model.train()
        running_loss = 0.0
        batch_count = 0

        for data, target in fold_train_loader:
            data, target = data.to(device, non_blocking=True), target.to(device, non_blocking=True)

            optimizer.zero_grad()
            output = model(data)
            loss = criterion(output, target)
            loss.backward()
            optimizer.step()

            running_loss += loss.item()
            batch_count += 1

        avg_loss = running_loss / max(1, batch_count)

        validation_metrics = _evaluate_loader_metrics(model, fold_validation_loader, device)
        current_score = metric_value(validation_metrics, selection_metric)

        if current_score > (best_selection_score + improvement_threshold):
            best_selection_score = current_score
            best_selection_metrics = validation_metrics
            best_model_state = {k: v.detach().clone() for k, v in model.state_dict().items()}
            best_epoch = epoch
            print(
                f"   Época {epoch}/{num_epochs}: loss={avg_loss:.4f}, "
                f"val_{selection_metric}={current_score:.2f}% *** NUEVO MEJOR ***"
            )

        improvement = current_score - last_improvement_score
        if improvement >= improvement_threshold:
            patience_counter = 0
            last_improvement_score = current_score
        else:
            patience_counter += 1

        if epoch % 30 == 0 or epoch == 1:
            print(
                f"   Época {epoch}/{num_epochs}: loss={avg_loss:.4f}, "
                f"val_{selection_metric}={current_score:.2f}% "
                f"(best={best_selection_score:.2f}%)"
            )

        if patience_counter >= patience:
            print(f"   Early stopping en época {epoch} (sin mejora por {patience} épocas)")
            break

    if best_model_state is not None:
        model.load_state_dict(best_model_state)
        print(
            f"\n   ✓ Cargado mejor modelo de época {best_epoch} "
            f"(validation {selection_metric}={best_selection_score:.2f}%)"
        )
    else:
        print("\n   ⚠ Usando modelo final (no se encontró mejora)")

    print("Evaluando con el mejor modelo sobre test held-out...")
    test_metrics = _evaluate_loader_metrics(model, fold_test_loader, device)
    if best_selection_metrics is None:
        best_selection_metrics = _evaluate_loader_metrics(model, fold_validation_loader, device)
        best_selection_score = metric_value(best_selection_metrics, selection_metric)
    best_validation_acc = metric_value(best_selection_metrics, "accuracy")

    print(f"\nResultados Fold {fold_num} (usando mejor modelo de época {best_epoch}):")
    print(f"   Accuracy:     {test_metrics['accuracy']:.2f}%")
    print(f"   Sensitivity:  {test_metrics['sensitivity']:.2f}%")
    print(f"   Specificity:  {test_metrics['specificity']:.2f}%")
    print(f"   F1-Score:     {test_metrics['f1_score']:.2f}%")
    print(f"   AUC:          {test_metrics['auc']:.2f}%")

    return {
        "fold": fold_num,
        "accuracy": test_metrics["accuracy"],
        "sensitivity": test_metrics["sensitivity"],
        "specificity": test_metrics["specificity"],
        "f1_score": test_metrics["f1_score"],
        "auc": test_metrics["auc"],
        "confusion_matrix": test_metrics["confusion_matrix"],
        "n_samples": test_metrics["n_samples"],
        "best_epoch": best_epoch,
        "selection_metric": selection_metric,
        "best_selection_score": float(best_selection_score),
        "best_selection_metrics": best_selection_metrics,
        "best_train_acc": best_validation_acc,
        "best_validation_acc": best_validation_acc,
        "selection_split": "validation",
        "evaluation_split": "test",
        "checkpoint_metric": config.get("checkpoint_metric", config.get("fitness_metric", "f1_score")),
        "best_validation_score": float(best_selection_score),
    }


def evaluate_5fold_cross_validation(
    best_genome: dict,
    config: dict,
    device: torch.device,
    num_epochs: Optional[int] = None,
    neuroevolution_instance=None
) -> Optional[Dict[str, Any]]:
    """
    Evaluate the best architecture using five train/validation/test partitions.

    Args:
        best_genome: Best architecture genome.
        config: System configuration dictionary.
        device: Device to train/evaluate on.
        num_epochs: Optional epochs per fold. If None, uses config['num_epochs'].
        neuroevolution_instance: Optional HybridNeuroevolution instance to load checkpoint.

    Returns:
        Aggregated 5-fold held-out test results dictionary or None if all folds fail.
    """
    # The selected genome is evaluated on real data only.  Do not reuse the
    # synthetic source used by the genetic loop, even if the caller's active
    # dataset selector still points at it.
    final_config = get_data_phase_config(config, 'final_evaluation')

    if num_epochs is None:
        num_epochs = config.get("num_epochs", 100)
    selection_metric = resolve_metric_name(config, "fold_selection_metric")

    print("=" * 80)
    print("EVALUACIÓN FINAL 5-FOLD CROSS-VALIDATION")
    print("=" * 80)

    print("\nIMPORTANTE: validación selecciona el mejor epoch y test se reserva para reporte final:")
    print(
        "   - Fuente de datos: real-only "
        f"({final_config['fold_files_subdirectory']}, {final_config['dataset_id']})"
    )
    print(f"   - Entrena por {num_epochs} épocas por fold")
    print(f"   - Guarda el MEJOR modelo basado en {selection_metric} de validación")
    print(f"   - Aplica early stopping con patience={config.get('epoch_patience', 10)}")
    print("   - Reporta métricas finales usando únicamente el split test")

    print("\nArquitectura a evaluar:")
    print(f"   Architecture: {_format_architecture(best_genome)}")
    if best_genome.get("architecture_template_id"):
        print(f"   Template: {best_genome.get('architecture_template_id')}")
        print(f"   Template Family: {best_genome.get('architecture_template_family', 'N/A')}")
        print(f"   Template Origin: {best_genome.get('architecture_template_origin', 'N/A')}")
    print(f"   Conv1D Layers: {best_genome['num_conv_layers']}")
    print(f"   FC Layers: {best_genome['num_fc_layers']}")
    print(f"   Residual Enabled: {best_genome.get('residual_enabled', False)}")
    if best_genome.get("residual_enabled", False):
        print(f"   Residual Block Size: {best_genome.get('residual_block_size', 2)}")
        print(f"   Residual Projection: {best_genome.get('residual_projection', 'auto')}")
    print(f"   Inception Enabled: {best_genome.get('inception_enabled', False)}")
    if best_genome.get("inception_enabled", False):
        print(f"   Inception Reduction Ratio: {best_genome.get('inception_reduction_ratio', 0.5)}")
        print(f"   Inception Pool Branch: {best_genome.get('inception_pool_branch', True)}")
    print(f"   Optimizer: {best_genome['optimizer']}")
    print(f"   Learning Rate: {best_genome['learning_rate']}")
    print(f"   Épocas por fold: {num_epochs}")

    if neuroevolution_instance is not None:
        print("\nLa evaluación final usa la arquitectura seleccionada y entrena desde cero por fold.")
        print("Los pesos del checkpoint evolutivo no se usan para métricas finales de test.")
    else:
        print("\nNo se proporcionó instancia de neuroevolution, entrenando desde cero")

    fold_results = []

    for fold_num in range(1, 6):
        print(f"\n\nCargando datos del Fold {fold_num}...")

        try:
            loaders = load_fold_loaders(final_config, fold_num, device=device)
            fold_train_loader = loaders.train
            fold_validation_loader = loaders.validation
            fold_test_loader = loaders.test
            print(f"   Train batches: {len(fold_train_loader)}")
            print(f"   Validation batches: {len(fold_validation_loader)}")
            print(f"   Test batches: {len(fold_test_loader)}")

            fold_result = evaluate_single_fold(
                best_genome,
                final_config,
                fold_train_loader,
                fold_validation_loader,
                fold_test_loader,
                fold_num,
                device=device,
                num_epochs=num_epochs,
            )
            fold_results.append(fold_result)

        except Exception as e:
            print(f"   ERROR en Fold {fold_num}: {e}")
            print("   Saltando este fold...")
            import traceback

            traceback.print_exc()
            continue

    print("\n\n" + "=" * 80)
    print("RESULTADOS AGREGADOS (5-FOLD TEST HELD-OUT)")
    print("=" * 80)

    if not fold_results:
        print("ERROR: No se pudo evaluar ningún fold")
        return None

    accuracies = [r["accuracy"] for r in fold_results]
    sensitivities = [r["sensitivity"] for r in fold_results]
    specificities = [r["specificity"] for r in fold_results]
    f1_scores = [r["f1_score"] for r in fold_results]
    aucs = [r["auc"] for r in fold_results]

    mean_accuracy = np.mean(accuracies)
    std_accuracy = np.std(accuracies)

    mean_sensitivity = np.mean(sensitivities)
    std_sensitivity = np.std(sensitivities)

    mean_specificity = np.mean(specificities)
    std_specificity = np.std(specificities)

    mean_f1 = np.mean(f1_scores)
    std_f1 = np.std(f1_scores)

    mean_auc = np.mean(aucs)
    std_auc = np.std(aucs)

    print("\nRESULTADOS POR FOLD:")
    print(f"{'Fold':<6} {'Accuracy':<12} {'Sensitivity':<14} {'Specificity':<14} {'F1-Score':<12} {'AUC':<12} {'Best Epoch':<12}")
    print("-" * 95)
    for r in fold_results:
        best_ep = r.get("best_epoch", "N/A")
        print(
            f"{r['fold']:<6} {r['accuracy']:>6.2f}%      {r['sensitivity']:>6.2f}%        "
            f"{r['specificity']:>6.2f}%        {r['f1_score']:>6.2f}%      {r['auc']:>6.2f}%      {best_ep}"
        )

    print("-" * 95)
    print(f"{'Mean':<6} {mean_accuracy:>6.2f}%      {mean_sensitivity:>6.2f}%        {mean_specificity:>6.2f}%        {mean_f1:>6.2f}%      {mean_auc:>6.2f}%")
    print(f"{'Std':<6} {std_accuracy:>6.2f}%      {std_sensitivity:>6.2f}%        {std_specificity:>6.2f}%        {std_f1:>6.2f}%      {std_auc:>6.2f}%")

    results = {
        "fold_results": fold_results,
        "mean_accuracy": mean_accuracy,
        "std_accuracy": std_accuracy,
        "mean_sensitivity": mean_sensitivity,
        "std_sensitivity": std_sensitivity,
        "mean_specificity": mean_specificity,
        "std_specificity": std_specificity,
        "mean_f1": mean_f1,
        "std_f1": std_f1,
        "mean_auc": mean_auc,
        "std_auc": std_auc,
        "n_folds": len(fold_results),
        "architecture": _format_architecture(best_genome),
        "num_epochs_used": num_epochs,
        "selection_metric": selection_metric,
        "selection_split": "validation",
        "evaluation_split": "test",
        "evolution_dataset_id": config.get('evolution_dataset_id', config.get('dataset_id')),
        "evolution_fold_files_subdirectory": config.get(
            'evolution_fold_files_subdirectory', config.get('fold_files_subdirectory')
        ),
        "final_dataset_id": final_config['dataset_id'],
        "final_fold_files_subdirectory": final_config['fold_files_subdirectory'],
    }

    print("\n" + "=" * 80)
    print("FORMATO PARA TABLA")
    print("=" * 80)

    print("\nMÉTRICAS FINALES (promedio ± desviación estándar):")
    print(f"   Accuracy:     {mean_accuracy:.2f}% ± {std_accuracy:.2f}%")
    print(f"   Sensitivity:  {mean_sensitivity:.2f}% ± {std_sensitivity:.2f}%")
    print(f"   Specificity:  {mean_specificity:.2f}% ± {std_specificity:.2f}%")
    print(f"   F1-Score:     {mean_f1:.2f}% ± {std_f1:.2f}%")
    print(f"   AUC:          {mean_auc:.2f}% ± {std_auc:.2f}%")

    print("\nFORMATO PARA TABLA (valores en escala 0-1):")
    print(f"   Model: Neuroevolution-{results['architecture']}")
    print(f"   Accuracy:     {mean_accuracy/100:.2f} ({int(std_accuracy)}%)")
    print(f"   Sensitivity:  {mean_sensitivity/100:.2f} ({int(std_sensitivity)}%)")
    print(f"   Specificity:  {mean_specificity/100:.2f} ({int(std_specificity)}%)")
    print(f"   F1-Score:     {mean_f1/100:.2f} ({int(std_f1)}%)")
    print(f"   AUC:          {mean_auc/100:.2f} ({int(std_auc)}%)")

    print("\nFORMATO LaTeX:")
    latex_row = (
        f"Neuroevolution-{results['architecture']} & {mean_accuracy/100:.2f} ({int(std_accuracy)}\\%) & "
        f"{mean_sensitivity/100:.2f} ({int(std_sensitivity)}\\%) & {mean_specificity/100:.2f} ({int(std_specificity)}\\%) & "
        f"{mean_f1/100:.2f} ({int(std_f1)}\\%) & {mean_auc/100:.2f} ({int(std_auc)}\\%) \\\\"
    )
    print(f"   {latex_row}")

    print("\nFORMATO Markdown:")
    markdown_row = (
        f"| Neuroevolution-{results['architecture']} | {mean_accuracy/100:.2f} ({int(std_accuracy)}%) | "
        f"{mean_sensitivity/100:.2f} ({int(std_sensitivity)}%) | {mean_specificity/100:.2f} ({int(std_specificity)}%) | "
        f"{mean_f1/100:.2f} ({int(std_f1)}%) | {mean_auc/100:.2f} ({int(std_auc)}%) |"
    )
    print(f"   {markdown_row}")

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    artifacts_dir = config.get("artifacts_dir", "artifacts/test_audio")
    os.makedirs(artifacts_dir, exist_ok=True)
    results_file = os.path.join(artifacts_dir, f"5fold_cv_results_{timestamp}.json")
    results["results_path"] = results_file

    try:
        with open(results_file, "w", encoding="utf-8") as f:
            json.dump(_to_json_compatible(results), f, indent=2)
        print(f"\n✓ Resultados guardados en: {results_file}")
    except Exception as e:
        print(f"\n✗ Error guardando resultados: {e}")

    print("\n" + "=" * 80)

    return results
